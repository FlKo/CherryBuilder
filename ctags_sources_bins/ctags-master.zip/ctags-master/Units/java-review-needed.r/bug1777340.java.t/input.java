public @interface bug1777340 {
    String n() default "ninjas; monkeys!";
    String m();
}
