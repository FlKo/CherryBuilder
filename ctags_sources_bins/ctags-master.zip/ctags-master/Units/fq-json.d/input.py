class A:
    def f():
        pass
