# 1 "./foo.h"
int main(void)
{
  return 0;
}
/* comment */
