int f01()
{
	return 0;
}

int f02(f02a01,f02a02)
  int f02a01;
  int f02a02;
{
	return f02a01 + f02a02;
}

int f03(void)
{
	return 0;
}

int f04(...)
{
	return 0;
}

int f05(
		f05a01,
		f05a02,
		...
	)
	unsigned short f05a01;
	int * f05a02;
{
	return 0;
}

int f06(f06a01,f06a02)
	unsigned short int f06a01, ** f06a02;
{
	return 0;
}

