/* Demonstrates temporary bug caused by statement reinitialization */
static wchar_t charset2uni[256] = {
};
