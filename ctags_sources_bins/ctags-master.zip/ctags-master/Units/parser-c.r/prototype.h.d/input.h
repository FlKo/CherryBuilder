int prototype_a (int a, char *b);
extern void prototype_b (void);
