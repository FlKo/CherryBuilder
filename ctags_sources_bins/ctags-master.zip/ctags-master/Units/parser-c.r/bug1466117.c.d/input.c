typedef struct mystruct {
	int a;
	int b;
};

typedef struct {
	int a;
	int b;
} mystruct;

