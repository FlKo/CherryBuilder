struct private {int x;} v24;
struct protected {int x;} v25;
struct public {int x;} v26;
struct s24 {int private;} ;
struct s25 {int protected;} ;
struct s26 {int public;} ;
typedef int private; /* 24 */
typedef int protected; /* 25 */
typedef int public; /* 26 */
int v24, private;
int v25, protected;
int v26, public;
int private (int a24);
int protected (int a25);
int public (int a26);
