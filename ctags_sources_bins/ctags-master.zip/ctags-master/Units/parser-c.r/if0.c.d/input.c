#if 0
int x;
#else
int y;
#endif
