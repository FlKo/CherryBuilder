#define F(X) X
#define G
#include <S.h>
#define Z(Y)					\
int main (void)					\
{						\
  return 0;					\
}
