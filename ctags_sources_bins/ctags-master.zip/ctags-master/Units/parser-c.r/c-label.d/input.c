int
main(int argc)
{
  goto out;
  switch (argc)
    {
    case 1:
      break;
    case A|B:
      break;
    default:
      break;
    }
   out:
  return 0;
}
