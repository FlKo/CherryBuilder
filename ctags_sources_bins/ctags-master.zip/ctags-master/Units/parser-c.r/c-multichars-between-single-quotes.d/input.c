char c[]={'o.'};
