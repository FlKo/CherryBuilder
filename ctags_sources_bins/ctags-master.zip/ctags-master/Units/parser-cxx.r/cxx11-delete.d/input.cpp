class Del
{
private:
    Del(const Del &) = delete;
    void operator=(const Del& rDel) = delete;
};
