// Taken from #1374 submitted by @oison-dan
struct alignas( 64 ) AlignasTestStruct
{
};

class alignas( 64 ) AlignasTestStruct2
{
};
