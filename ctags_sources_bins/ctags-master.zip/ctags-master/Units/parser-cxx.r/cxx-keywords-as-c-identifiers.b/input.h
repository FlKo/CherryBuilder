struct NotKeyword {int x;} v0;
struct alignas {int x;} v1;
struct alignof {int x;} v2;
struct bool {int x;} v3;
struct catch {int x;} v4;
struct char16_t {int x;} v5;
struct char32_t {int x;} v6;
struct class {int x;} v7;
struct concept {int x;} v8;
struct constexpr {int x;} v9;
struct const_cast {int x;} v10;
struct decltype {int x;} v11;
struct delete {int x;} v12;
struct dynamic_cast {int x;} v13;
struct explicit {int x;} v14;
struct export {int x;} v15;
struct final {int x;} v16;
struct friend {int x;} v17;
struct mutable {int x;} v18;
struct namespace {int x;} v19;
struct new {int x;} v20;
struct noexcept {int x;} v21;
struct nullptr {int x;} v22;
struct operator {int x;} v23;
struct private {int x;} v24;
struct protected {int x;} v25;
struct public {int x;} v26;
struct reinterpret_cast {int x;} v27;
struct requires {int x;} v28;
struct static_assert {int x;} v29;
struct static_cast {int x;} v30;
struct template {int x;} v31;
struct this {int x;} v32;
struct thread_local {int x;} v33;
struct throw {int x;} v34;
struct try {int x;} v35;
struct typeid {int x;} v36;
struct typename {int x;} v37;
struct using {int x;} v38;
struct virtual {int x;} v39;
struct s0 {int NotKeyword;} ;
struct s1 {int alignas;} ;
struct s2 {int alignof;} ;
struct s3 {int bool;} ;
struct s4 {int catch;} ;
struct s5 {int char16_t;} ;
struct s6 {int char32_t;} ;
struct s7 {int class;} ;
struct s8 {int concept;} ;
struct s9 {int constexpr;} ;
struct s10 {int const_cast;} ;
struct s11 {int decltype;} ;
struct s12 {int delete;} ;
struct s13 {int dynamic_cast;} ;
struct s14 {int explicit;} ;
struct s15 {int export;} ;
struct s16 {int final;} ;
struct s17 {int friend;} ;
struct s18 {int mutable;} ;
struct s19 {int namespace;} ;
struct s20 {int new;} ;
struct s21 {int noexcept;} ;
struct s22 {int nullptr;} ;
struct s23 {int operator;} ;
struct s24 {int private;} ;
struct s25 {int protected;} ;
struct s26 {int public;} ;
struct s27 {int reinterpret_cast;} ;
struct s28 {int requires;} ;
struct s29 {int static_assert;} ;
struct s30 {int static_cast;} ;
struct s31 {int template;} ;
struct s32 {int this;} ;
struct s33 {int thread_local;} ;
struct s34 {int throw;} ;
struct s35 {int try;} ;
struct s36 {int typeid;} ;
struct s37 {int typename;} ;
struct s38 {int using;} ;
struct s39 {int virtual;} ;
typedef int NotKeyword; /* 0 */
typedef int alignas; /* 1 */
typedef int alignof; /* 2 */
typedef int bool; /* 3 */
typedef int catch; /* 4 */
typedef int char16_t; /* 5 */
typedef int char32_t; /* 6 */
typedef int class; /* 7 */
typedef int concept; /* 8 */
typedef int constexpr; /* 9 */
typedef int const_cast; /* 10 */
typedef int decltype; /* 11 */
typedef int delete; /* 12 */
typedef int dynamic_cast; /* 13 */
typedef int explicit; /* 14 */
typedef int export; /* 15 */
typedef int final; /* 16 */
typedef int friend; /* 17 */
typedef int mutable; /* 18 */
typedef int namespace; /* 19 */
typedef int new; /* 20 */
typedef int noexcept; /* 21 */
typedef int nullptr; /* 22 */
typedef int operator; /* 23 */
typedef int private; /* 24 */
typedef int protected; /* 25 */
typedef int public; /* 26 */
typedef int reinterpret_cast; /* 27 */
typedef int requires; /* 28 */
typedef int static_assert; /* 29 */
typedef int static_cast; /* 30 */
typedef int template; /* 31 */
typedef int this; /* 32 */
typedef int thread_local; /* 33 */
typedef int throw; /* 34 */
typedef int try; /* 35 */
typedef int typeid; /* 36 */
typedef int typename; /* 37 */
typedef int using; /* 38 */
typedef int virtual; /* 39 */
int v0, NotKeyword;
int v1, alignas;
int v2, alignof;
int v3, bool;
int v4, catch;
int v5, char16_t;
int v6, char32_t;
int v7, class;
int v8, concept;
int v9, constexpr;
int v10, const_cast;
int v11, decltype;
int v12, delete;
int v13, dynamic_cast;
int v14, explicit;
int v15, export;
int v16, final;
int v17, friend;
int v18, mutable;
int v19, namespace;
int v20, new;
int v21, noexcept;
int v22, nullptr;
int v23, operator;
int v24, private;
int v25, protected;
int v26, public;
int v27, reinterpret_cast;
int v28, requires;
int v29, static_assert;
int v30, static_cast;
int v31, template;
int v32, this;
int v33, thread_local;
int v34, throw;
int v35, try;
int v36, typeid;
int v37, typename;
int v38, using;
int v39, virtual;
int NotKeyword (int a0);
int alignas (int a1);
int alignof (int a2);
int bool (int a3);
int catch (int a4);
int char16_t (int a5);
int char32_t (int a6);
int class (int a7);
int concept (int a8);
int constexpr (int a9);
int const_cast (int a10);
int decltype (int a11);
int delete (int a12);
int dynamic_cast (int a13);
int explicit (int a14);
int export (int a15);
int final (int a16);
int friend (int a17);
int mutable (int a18);
int namespace (int a19);
int new (int a20);
int noexcept (int a21);
int nullptr (int a22);
int operator (int a23);
int private (int a24);
int protected (int a25);
int public (int a26);
int reinterpret_cast (int a27);
int requires (int a28);
int static_assert (int a29);
int static_cast (int a30);
int template (int a31);
int this (int a32);
int thread_local (int a33);
int throw (int a34);
int try (int a35);
int typeid (int a36);
int typename (int a37);
int using (int a38);
int virtual (int a39);
