namespace TheNamespace {
	class MyClass { };
	int variable;
}
