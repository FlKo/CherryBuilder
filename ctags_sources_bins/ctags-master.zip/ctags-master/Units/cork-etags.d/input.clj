(ns app.controller)

 (defn empty-fn [])

(defn function-with-body []
    (println "body"))

'(defn quoted-function [])
(quote quoted-function2 [])
