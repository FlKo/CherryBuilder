int
main(void)
{
  define a;
  return a;
}
