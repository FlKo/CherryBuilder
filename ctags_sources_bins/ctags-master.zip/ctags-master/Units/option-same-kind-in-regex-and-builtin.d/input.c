unsigned int level = 42;
int
main(void)
{
  define a;
  return a;
}
