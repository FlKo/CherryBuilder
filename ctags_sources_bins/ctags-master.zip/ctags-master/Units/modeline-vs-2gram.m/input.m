% -*- objc -*-
% ABOVE MODELINE IS JUST FOR TESTING
function [xn,fn,fcall] = backtrack(xc,d,fc,fnc,DDfnc,c,gamma,eps)
