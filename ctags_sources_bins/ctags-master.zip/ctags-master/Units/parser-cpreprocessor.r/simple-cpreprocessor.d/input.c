#define X 1
#include <stdio.h>
/*
#define Y 2
*/

// #define Z 3
