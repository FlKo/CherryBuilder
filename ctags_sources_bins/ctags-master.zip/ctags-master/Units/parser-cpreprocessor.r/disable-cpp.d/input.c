#define X 1

int
main(int argc)
{
	return X;
}
