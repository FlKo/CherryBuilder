class C {
	public String a() {
		return @"c:\";
	}
	// this tag is missing in ctags 5.6
	public void b() {
	}
}
