using Gtk;
public class C {
 private Gtk.Window window;
 private string title;
}
